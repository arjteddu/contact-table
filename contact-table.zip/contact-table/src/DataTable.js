import React, { useState, useEffect } from 'react';

export const DataTable = (props) => {
  const [data, setData] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [showEditor, setEditor] = useState(false);
  const dataObj = {id:'',name:'',email:'',contact:''};

  useEffect(()=>{
    if(data){
      console.log('data',data);
      setSelectedIndex(data.length-1);
    }
  },[data])



  const onAdd = (evt)=>{
    console.log(evt);
    const tempArr = [...data];
    tempArr.push(dataObj);
    setData(tempArr);
    setEditor(true);
    setSelectedRow({});
  
  }

  const onRowClick = (index,row)=>{
    setSelectedRow(row);
    setSelectedIndex(index);
    setEditor(true);
  }

  return (
    <div>
      <p>Search</p>
      <input type="text"></input>
      <button onClick={onAdd}>
        Add
      </button>
      <br />
      <div style={{borderRight:'1px solid #add8e6',float:'left'}}>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Contact</th>
            </tr>
          </thead>
          <tbody>
          {data.map((row,index)=>{
            return (
              <tr key={index} style={{backgroundColor:index===selectedIndex?'#add8e6':''}} onClick={()=>onRowClick(index,row)}>
                <td>{row.id}</td>
                <td>{row.name}</td>
                <td>{row.email}</td>
                <td>{row.contact}</td>
              </tr>
            )
          })}
          </tbody>
        </table>
      </div>
      <EditBlock row={selectedRow} index={selectedIndex} dataSetter={setData} data={data} showEditor={showEditor} setEditor={setEditor} />
    </div>
  );
}

const EditBlock = ({row, index,dataSetter,data,showEditor,setEditor})=>{
  const [contactObj, setContactObj] = useState({name:'',email:'',contact:''});
  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [contact,setContact] = useState('');

  useEffect(()=>{
    //if(row){
      setName(row && row.name || '');
      setEmail(row && row.email || '');
      setContact(row && row.contact || '');
    //}
  },[row])

  const onTextChange = (e)=>{
    const {id,value} = e.currentTarget;
    switch(id){
      case 'name':
        setName(value);
        break;
      case 'email':
        setEmail(value);
      break;
      case 'contact':
        setContact(value);
      break;
    }
    const dataIndex = !showEditor ? data[index]:contactObj;
    const tempObj = {...dataIndex};
    tempObj[id] = value;
    setContactObj(tempObj);
  }
  const onSave =(e)=>{
    const id = !showEditor? data[index]:contactObj;
    const obj = Object.assign(id,contactObj);
    const tempData = [...data];
    tempData[index]=obj;
    dataSetter(tempData);
    setEditor(false);
  }
  return (
      <>
      { (showEditor) && 
      <div>
      <table>
          <thead>
            <tr>
              <th>Customer ID</th>
              <th>1 (Read Only)</th>
            </tr>
          </thead>
          <tbody>
              <tr>
                <td>Name</td>
                <td><input id='name' type='text' onChange={onTextChange} value={name}></input></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><input id='email' type='text' onChange={onTextChange} value={email}></input></td>
              </tr>
              <tr>
                <td>Contact</td>
                <td><input id='contact' type='text' onChange={onTextChange} value={contact}></input></td>
              </tr>
          </tbody>
        </table>
        <button onClick={onSave}>
         Save
        </button>
      </div>
      }
    </>
  )
}
