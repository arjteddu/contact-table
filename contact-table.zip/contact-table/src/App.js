import { DataTable } from './DataTable';
import './App.css';

function App() {
  return (
    <div>
      <DataTable></DataTable>
    </div>
  );
}

export default App;
